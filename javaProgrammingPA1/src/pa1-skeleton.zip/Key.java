package pa1;

public class Key extends GameObject{

	public Key() {
		/* add your code, you can add parameter, too */

	}
}
