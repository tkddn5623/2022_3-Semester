package pa1;

public class Player extends GameObject{
	
	public Player() {
		/* add your code, you can add parameter, too */
	}	
	
	public void move() {
		/* add your code, you can add parameter, too */

	}
}
