package pa1;

public class Door extends GameObject{
	
	public Door(  ) {
		/* add your code, you can add parameter, too */

	}
	
}
