package pa1;

public class Board implements Game {
	Player player;
	Ghost ghost;
	Key key;
	Door door;

	public Board() {		
		/* add your code, you can add parameter, too */

	}
	
	public void printBoard() {
		/* add your code, you can add parameter, too */

	}

	public void initObjects() {
		/* add your code, you can add parameter, too */

	}
	
	public void movePlayer() {
		/* add your code, you can add parameter, too */

	}	
	
	public void moveGhost() {
		/* add your code, you can add parameter, too */

	}
	
	public boolean isFinish() {
		/* add your code, you can add parameter, too */

	}
}
