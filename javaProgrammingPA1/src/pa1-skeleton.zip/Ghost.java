package pa1;

public class Ghost extends GameObject{
	
	public Ghost(      ) {
		/* add your code, you can add parameter, too */

	}	
	
	public void move() {
		/* add your code, you can add parameter, too */

	}
	
}
